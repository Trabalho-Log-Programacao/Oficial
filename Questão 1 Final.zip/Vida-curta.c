#include<stdio.h>
main(){
    int d, m, a, t;
    printf("Seus dias, mese e anos de vida:");
scanf("%d%d%d", &d, &m, &a);
t = d + m * (365.25/12) + a * 365.25;
    printf("Seus dias de vida total eh: %d\n", t);
    return 0;
}