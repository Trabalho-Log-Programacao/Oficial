var d = prompt('Dias de vida: '); //Dias de vida
var m = prompt('Meses de vida: '); //Meses de via
var a = prompt('Anos de vida: '); //Anos de vida

t = d + m * (365.25/12) + a * 365.25;

console.log('Total de Dias Vivido eh: '+Math.floor(t));
alert('Total de Dias Vivido eh: ' + Math.floor(t));

